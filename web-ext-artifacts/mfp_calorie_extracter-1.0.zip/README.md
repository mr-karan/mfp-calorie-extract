<img src="./icons/icons8-cute-pumpkin-48.png" align="right" />

# MFP Calorie Extractor

Browser extension which copies macronutrients information from MFP website and pastes the contents as comma separated values in clipboard. It can be used to paste the details in Excel/Google Sheets for easy calorie tracking.

## See it in action

